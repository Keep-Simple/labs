function res = pow_modulo(x, n, m)
%x - base of power
%n - power
%m - modulo
    
    res = 1;
    for i = 1:n
        res = mod(res*x,m);
    end
end