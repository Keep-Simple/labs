%RSA
M = 'MATUSHEVYCH YAROSLAV'; %message
p = 17;
q = 31;
n = p*q;
phi = (p-1)*(q-1);

e = 7;
d = 343;

alph = 'A':'Z';
Map(alph(1:26)) = 1:26;
MNUM = Map(M); %message to numbers
disp('Original message in numbers');
disp(MNUM);

N = size(MNUM,2);

%encryption
E = zeros(1,N);
for i = 1:N
    E(i) = pow_modulo(MNUM(i),e,n);
end
disp('Encrypted');
disp(E);

%decryption
D = zeros(1,N);
for i = 1:N
    D(i) = pow_modulo(E(i),d,n);
end
disp('Decrypted');
disp(D);