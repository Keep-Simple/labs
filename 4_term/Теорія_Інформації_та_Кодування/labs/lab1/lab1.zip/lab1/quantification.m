function quantification
dt = 0.2;
Tc = 6.28;
T = 0:dt:Tc;
Q = f(T);

R = [T; Q];

fileID = fopen('Q.txt','w');
fprintf(fileID,'%.2f\t%.4f\r\n',R);
fclose(fileID);

upper = max(Q);
lower = min(Q);
step = (upper-lower)/31;

figure 
    stem(T, Q);
    hold on;
    for i=1:32
        level = lower + (i-1)*step;
        plot([0 Tc], [level level], '--k');
        text(-0.5,level, dec2bin(i-1, 5));
        hold on;
    end

    function Y = f(t)
        y1 = 18*sin(t);
        y2 = 44*sin(11*t);
        y3 = 18*cos(10*t);
        Y = y1+y2+y3;
    end

end