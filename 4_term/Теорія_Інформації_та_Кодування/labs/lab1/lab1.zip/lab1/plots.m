%plots
t = 1:0.01:2.5;

y1 = 18*sin(t);
y2 = 44*sin(11*t);
y3 = 18*cos(10*t);
Y = y1+y2+y3;

figure
    plot(t, y1, '--g',t, y2,'--r', t, y3,'--b', t, Y,'k');
    legend('y_1(t)','y_2(t)', 'y_3(t)', 'Y(t)');
    xlabel('t');
    grid on;
    