%restore
fileID = fopen('Q.txt','r');
R = fscanf(fileID,'%f%f',[2 Inf]);
fclose(fileID);

N = size(R,2);

figure 
    stem(R(1,:),R(2,:)); 
    hold on;
    for i = 1:N-1
        plot([R(1,i) R(1,i+1)], [R(2,i),R(2,i+1)],'r');
        hold on;
    end
    xlabel('t');

dt = 0.2;
Tc = 6.28;
Ti = R(2,:);
Yi = R(2,:);

t = 0:0.01:Tc;
Nt = size(t,2);

Y = zeros(1, Nt);
dY = zeros(1, Nt);

figure
    for i=1:N
        for j = 1:Nt
            dY(j) = Yi(i)*sin(pi*(t(j)-dt*(i-1))/dt)/(pi*(t(j)-dt*(i-1))/dt);
        end
        Y = Y + dY;
        plot(t, Y, '--');
        hold on;
    end
    xlabel('t');

%deviation
y1 = 18*sin(t);
y2 = 44*sin(11*t);
y3 = 18*cos(10*t);
Yd = y1+y2+y3;

eps = abs(Y-Yd);
mean_eps = nanmean(eps);
var_eps = nanvar(eps);

figure
    plot(t,Y, t,Yd);
    xlabel('t');
    legend('Y restored', 'Y input');

figure
    plot(t, eps);
    xlabel('t');
    ylabel('$\epsilon (t)$','interpreter', 'latex');
    legend(['mean = ' num2str(mean_eps) ', D = ' num2str(var_eps)]);
 


    


    
    


